/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ecommerce_system;

/**
 *
 * @author marii
 */
public class Cart {
 protected int customerId ;
protected int nProducts;
  protected Product[]products;
 
    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        if( customerId>=1)
        this.customerId = customerId;
        else
        this.customerId=Math.abs( customerId);
    }

    public int getnPoducts() {
        return nProducts;
    }

    public void setnPoducts(int nPoducts) {
        if(nPoducts>=1)
         this.nProducts = nPoducts;
        else
          this.nProducts=Math.abs(nPoducts);
    }

    public Product[] getProducts() {
        return products;
    }

    public void setProducts(Product[] products) {
        this.products =new Product[nProducts] ;
    }
 public void addProduct(Product p ){
     for(int i=0;i<nProducts;i++){
         if(products[i]==null){
            products[i]=p;
        return;   
     }
     }
     System.out.println("the cart is full");
 }
 public float calculatePrice(){
     
 float totalPrice=0;
     for(int i=0;i<products.length;i++){
      if( products[i] !=null)
      totalPrice+= products[i].getPrice();
     }
      return totalPrice;
 }
 public void removeProduct(int n){
     if(n>=0&&n<nProducts )
         products[n]=null;
     else
         System.out.println("invalid index");
 }
 public void placeorder(Order order,int x) {
      switch (x){
      case 1:
          order.printOrderInfo();
      case 2:
         for(Product p:products){
     products=null;
 }   
 }

 }
}   

