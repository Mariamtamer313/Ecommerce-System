/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ecommerce_system;

/**
 *
 * @author marii
 */
public class Product {
   protected int productID;
  protected String name;
  protected float price;

    public void setProductID(int ID) {   
        if(ID>=1)
  this.productID=ID;
else
    this.productID=Math.abs(ID);
       // this.productID = productID;
    }
    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(float price) {
        if(price>=0)
        this.price = price;
        else
            this.price=Math.abs(price);
    }

    public int getProductID() {
        return productID;
    }
    public String getName() {
        return name;
    }
    public float getPrice() {
        return price;
    }
}  

