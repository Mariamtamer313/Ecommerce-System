/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ecommerce_system;

import java.util.Scanner;

/**
 *
 * @author marii
 */
public class Ecommerce_system {

    public static void main(String[] args) {
       Scanner input=new Scanner(System.in);
    ElectronicProduct product1=new ElectronicProduct();
    product1.setName("smartPhone");
    product1.setBrand("samsung");
    product1.setWarrantyPeriod(1);
    product1.setProductID(1);
    product1.setPrice((float)599.9);
      
    ClothingProduct product=new ClothingProduct();
    product.setName("T-shirt");
    product.setProductID(2);
    product.setSize("medium");
    product.setPrice((float)19.99);
    product.setFabric("cotton");
    
    BookProduct book=new BookProduct();
    book.setAuthor("o'Reilly");
    book.setPublisher("X Publications");
    book.setName("oop");
    book.setPrice((float)39.99);
    book.setProductID(3);
    
    Customer customer1=new Customer();
   
    Cart c=new Cart();
        System.out.println("welcome to the E-commerce System!please enter your id");
      
        customer1.setCustomerId(input.nextInt());
        System.out.println("please enter your name");
       customer1.setName(input.next());
        System.out.println("please enter your address");
      
        customer1.address=input.next();
        System.out.println("How many products you want to add to your cart?");
    
        c.nProducts=input.nextInt();
        c.products=new Product[c.nProducts];
        for(int v=0;v<c.nProducts;v++){
        System.out.println("which product would you like to add? 1-smartPhone 2- T-shirt 3- oop");
            int p=input.nextInt();
              switch(p){
                case 1:
                   c.addProduct(product1);
                 
                     break;
                case 2:
                   c.addProduct(product);
                   break;
               case 3:
                   c.addProduct(book);
                  break;
           default:System.out.println("not found");
        }
        }
    Order o=new Order(customer1.customerId,1,c.getProducts(),c.calculatePrice());
 System.out.println("your total is :"+c.calculatePrice()+ "would you like to place the order ? 1-yes 2- no" );
  int x=input.nextInt();
c.placeorder(o, x);
             
        }
          
              
      
  }

        
    

        
    
    



    
