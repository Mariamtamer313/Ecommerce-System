/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ecommerce_system;

/**
 *
 * @author marii
 */
public class Customer {
    String name,address;
  int customerId;

    public void getName() {
        System.out.println(name);
    }

    public void setName(String name) {
        this.name = name;
    }

    public void getAddress() {
        System.out.println(address);  
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void getCustomerId() {
        System.out.println(customerId); 
        
    }

    public void setCustomerId(int customerId) {
        if(customerId>=1)
        this.customerId = customerId;
        else
            this.customerId=Math.abs(customerId);
    }
}


