/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ecommerce_system;

/**
 *
 * @author marii
 */
public class Order {
     public int customerId;
    public int orderId;
    int nProducts;
   Product[]products=new Product[nProducts]; 
   public float totalPrice;
    
   public Order(int customerId,int orderId,Product[]products,float totalPrice ){
       if(customerId>=0)
           this.customerId=customerId;
       else
           this.customerId=Math.abs(customerId);
       if(orderId>=0)
           this.orderId=orderId;
       else
           this.orderId=Math.abs(orderId);
       this.products=products;
       if(totalPrice>0)
           this.totalPrice=totalPrice;
       else
           this.totalPrice=Math.abs(totalPrice);
   }
   public void printOrderInfo(){
       System.out.println("order ID :"+this.orderId);
       System.out.println("Customer ID :"+this.customerId);
       System.out.println("products :");
        for(int i=0;i<products.length;i++){
           if(products[i] !=null)
            System.out.println(products[i].getName()+"-"+products[i].getPrice());
        }
 float totalPrice=0;
     for(int i=0;i<products.length;i++){
      if( products[i] !=null)
      totalPrice+= products[i].getPrice();
     }
    System.out.println("Total price :"+totalPrice); 
   }
}


